<strong>** DO NOT DISTRIBUTE OR PUBLICLY POST SOLUTIONS TO THESE LABS. MAKE ALL FORKS OF THIS REPOSITORY WITH SOLUTION CODE PRIVATE. PLEASE REFER TO THE STUDENT CODE OF CONDUCT AND ETHICAL EXPECTATIONS FOR COLLEGE OF INFORMATION TECHNOLOGY STUDENTS FOR SPECIFICS. ** </strong>

# WESTERN GOVERNOR UNIVERSITY 
## D287 – JAVA FRAMEWORKS

## C). Customize the HTML user interface for your customer's application. The user interface should include the shop name, the product names, and the names of the parts. 

>In mainscreen.html line 14 changed to My Fishing Shop. 
> Line 19 changed to Fishing Shop. 

## D). Add an "About" page to the application to describe your chosen customer's company to web viewers and include navigation to and from the "About" page and the main screen.
>Creation of the aboutscreen.html. 
>In mainscreen.html on line 19 added anchor tag to the aboutscreen inside a button.
> In MainScreenControllerr.java line 55 added @GetMapping for the /aboutscreen.

## E). Add a sample inventory for your chosen store to the application. You should have five parts and five products in your sample inventory and should not overwrite existing data in the database.
>Line 48 in BootStrapData.java adds if statement so only initializes data if products and parts inventories are empty.
> Line 49-101 in BootStrapData.java is the creation of the sample inventory for products and parts.
 
## F). Add a "Buy Now" button to your product list.
>Line 85 in mainscreen.html Add Buy button and connect it to controller method.
>Create buyProduct.html and errorBuyProduct.html pages to show messages when you have either successfully or unsuccessfully bought a product.
> Line 93-94 in Product.java add buy inventory class that decrements the inventory by one.
> Line 171-181 in AddProductController.java add method to find product by ID and then call buyInv method on the product. Returns you to successfully bought page or unsuccessfully bought page depending on if the product is in stock. 

## G).
> Line 7 in application.properties changed url to jdbc:h2:file:~/spring-boot-h2-db101
> Line 26-30 in InhousePartForm.html added text where error will print out onto the screen if an error exists.
> Line 27-31 in OutscouredPartForm.html added text where error will print out onto the screen if an error exists.
> Lines 65,66,75,76,85,86,95,96,105,106 in BootStrapData.java set min and max inv to each part in the sample data.
> Line 48-49 in mainscreen.html added columns for max and min inventory.
> In Part.java Line 33-34 added int maxInv and minInv. In Line 48,49  and 57-58 added maxInv and minInv to constructors. Line 101-116 added setters and getters for minInv and maxInv.

## H). Add validation for between or at the maximum and minimum fields.
>Created InvValidValidator.java annotation for custom validation if inventory is not between min and max inventory.
>Created ValidInventory.java class for custom validation if inventory is not between min and max inventory.
> In Part.java: Line 20 added InvValidValidator over the Part class.

## I). Add at least two unit tests for the maximum and minimum fields to the PartTest class in the test package.
>In PartTest.java Line 160-177 test for minInv and maxInv created. Tests check that the setter and getter methods work to compare the inventory to the minimum or maximum inventory.

## J). Remove the class files for any unused validators in order to clean your code. 
>Delete DeletePartValidator.java from validator package.