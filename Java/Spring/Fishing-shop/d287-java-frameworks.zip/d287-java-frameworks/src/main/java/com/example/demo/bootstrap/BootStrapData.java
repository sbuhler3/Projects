package com.example.demo.bootstrap;

import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.service.OutsourcedPartService;
import com.example.demo.service.OutsourcedPartServiceImpl;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 *
 *
 *
 *
 */
@Component
public class BootStrapData implements CommandLineRunner {

    private final PartRepository partRepository;
    private final ProductRepository productRepository;

    private final OutsourcedPartRepository outsourcedPartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository, OutsourcedPartRepository outsourcedPartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.outsourcedPartRepository=outsourcedPartRepository;
    }

    @Override
    public void run(String... args) throws Exception {


        List<OutsourcedPart> outsourcedParts=(List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            System.out.println(part.getName()+" "+part.getCompanyName());
        }
        if ((productRepository.count() < 1) && (partRepository.count() < 1)) {
            Product flyRodCombo = new Product("Fly Rod Combo", 150.0, 15);
            Product spinRodCombo = new Product("Spin Rod Combo", 100.0, 15);
            Product castRodCombo = new Product("Casting Rod Combo", 120.0, 10 );
            Product saltwaterRodCombo = new Product("Saltwater Rod Combo", 140.0,8);
            Product kidRodCombo = new Product("Kid Rod Combo", 50.0,9);
            productRepository.save(flyRodCombo);
            productRepository.save(spinRodCombo);
            productRepository.save(castRodCombo);
            productRepository.save(saltwaterRodCombo);
            productRepository.save(kidRodCombo);

            OutsourcedPart flyRod = new OutsourcedPart();
            flyRod.setCompanyName("Western Governors University");
            flyRod.setName("Fly Rod");
            flyRod.setInv(5);
            flyRod.setMinInv(2);
            flyRod.setMaxInv(10);
            flyRod.setPrice(100.0);
            flyRod.setId(100);
            outsourcedPartRepository.save(flyRod);

            OutsourcedPart spinRod = new OutsourcedPart();
            spinRod.setCompanyName("Western Governors University");
            spinRod.setName("Spin Rod");
            spinRod.setInv(8);
            spinRod.setMinInv(1);
            spinRod.setMaxInv(15);
            spinRod.setPrice(60.0);
            spinRod.setId(200);
            outsourcedPartRepository.save(spinRod);

            OutsourcedPart flyReel = new OutsourcedPart();
            flyReel.setCompanyName("Western Governors University");
            flyReel.setName("Fly Reel");
            flyReel.setInv(10);
            flyReel.setMinInv(3);
            flyReel.setMaxInv(15);
            flyReel.setPrice(30.0);
            flyReel.setId(300);
            outsourcedPartRepository.save(flyReel);

            OutsourcedPart spinReel = new OutsourcedPart();
            spinReel.setCompanyName("Western Governors University");
            spinReel.setName("Spin Reel");
            spinReel.setInv(15);
            spinReel.setMinInv(2);
            spinReel.setMaxInv(22);
            spinReel.setPrice(20.0);
            spinReel.setId(400);
            outsourcedPartRepository.save(spinReel);

            OutsourcedPart fishingLine = new OutsourcedPart();
            fishingLine.setCompanyName("Western Governors University");
            fishingLine.setName("Fishing Line");
            fishingLine.setInv(20);
            fishingLine.setMinInv(5);
            fishingLine.setMaxInv(30);
            fishingLine.setPrice(20.0);
            fishingLine.setId(500);
            outsourcedPartRepository.save(fishingLine);
        }



        System.out.println("Started in Bootstrap");
        System.out.println("Number of Products"+productRepository.count());
        System.out.println(productRepository.findAll());
        System.out.println("Number of Parts"+partRepository.count());
        System.out.println(partRepository.findAll());

    }
}
