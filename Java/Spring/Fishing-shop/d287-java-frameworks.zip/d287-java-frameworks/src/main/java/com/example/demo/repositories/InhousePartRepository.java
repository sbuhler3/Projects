package com.example.demo.repositories;

import com.example.demo.domain.InhousePart;
import org.springframework.data.repository.CrudRepository;

/**
 *
 *
 *
 *
 */
public interface InhousePartRepository extends CrudRepository<InhousePart,Long> {
}
