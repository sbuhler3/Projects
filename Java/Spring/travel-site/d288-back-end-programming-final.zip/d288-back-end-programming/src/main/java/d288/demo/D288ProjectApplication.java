package d288.demo;

import d288.demo.dao.VacationRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D288ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(D288ProjectApplication.class, args);
	}

}
