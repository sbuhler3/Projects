package d288.demo.services;

import d288.demo.entities.Cart;
import d288.demo.entities.CartItem;
import lombok.Data;

import java.util.Set;

@Data
public class Purchase {
    private Cart cart;
    private Set<CartItem> cartItems;

}
