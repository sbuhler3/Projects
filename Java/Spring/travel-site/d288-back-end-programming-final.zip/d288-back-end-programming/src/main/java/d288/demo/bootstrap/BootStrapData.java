package d288.demo.bootstrap;

import d288.demo.dao.CustomerRepository;
import d288.demo.entities.Customer;
import d288.demo.entities.Division;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapData implements CommandLineRunner {
    private final CustomerRepository customerRepository;

    public BootStrapData(CustomerRepository customerRepository){
        this.customerRepository = customerRepository;
    }
    @Override
    public void run(String... args) throws Exception {
        if (customerRepository.count() < 2) {
            Customer customer1 = new Customer();
            Customer customer2 = new Customer();
            Customer customer3 = new Customer();
            Customer customer4 = new Customer();
            Customer customer5 = new Customer();
            Division division = new Division();
            division.setId(10L);
            customer1.setFirstName("Jane");
            customer1.setLastName("Doe");
            customer1.setAddress("546 Abc");
            customer1.setPhone("222-222-2222");
            customer1.setDivision(division);
            customerRepository.save(customer1);

            customer2.setFirstName("Test");
            customer2.setLastName("Case");
            customer2.setAddress("546 Abc");
            customer2.setPhone("223-222-2222");
            customer2.setDivision(division);
            customerRepository.save(customer2);

            customer3.setFirstName("Case");
            customer3.setLastName("Test");
            customer3.setAddress("546 Abc");
            customer3.setPhone("224-222-2222");
            customer3.setDivision(division);
            customerRepository.save(customer3);

            customer4.setFirstName("Another Test");
            customer4.setLastName("Case");
            customer4.setAddress("546 Abc");
            customer4.setPhone("226-222-2222");
            customer4.setDivision(division);
            customerRepository.save(customer4);

            customer5.setFirstName("Final Test");
            customer5.setLastName("Case");
            customer5.setAddress("546 Abc");
            customer5.setPhone("227-222-2222");
            customer5.setDivision(division);
            customerRepository.save(customer5);
        }
    }
}
