package d288.demo.entities;

public enum StatusType {
    pending, ordered, cancelled
}
