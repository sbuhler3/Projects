package d288.demo.services;

public interface CheckoutService {
    PurchaseResponse placeOrder(Purchase purchase);
}
