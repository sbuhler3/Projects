package d288.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D288ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
