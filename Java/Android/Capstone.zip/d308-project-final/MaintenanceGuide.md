Version 1.1

This current version has passed all beta testing and is cleared to deploy.

Currently, the application does not host sensitive information such as passwords, credit cards, 
passports, etc. As the application evolves to a more expansive app it is likely such features will 
be added. Due to this, it is imperative that up-to-date security is added to the application
on the necessary components.

The infrastructure of the application exists on AWS, but a regular check for the application speed,
performance, and efficiency should be done quarterly. These metrics are available on AWS. Outside of that
the customer base can expect bi-annual updates to the application for the next 5 years to help it remain
relevant.

Updates for correcting bugs will be done quarterly, unless a bug is reported as critical
and terminates the application. The application may not run correctly on any predecessor to Android 8.0.

