package com.example.vacation.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.vacation.R;
import com.example.vacation.database.Repository;
import com.example.vacation.entities.Excursion;
import com.example.vacation.entities.Vacation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

public class VacationDetails extends AppCompatActivity {
EditText editVacationTitle;
EditText editHotel;
String vacationTitle;
String hotel;
String startVacation;
String endVacation;
int id;
Vacation vacation;
Vacation currentVacation;
Repository repository;
boolean valid = false;

//Logic for date calendar buttons

Button startButton;
Button endButton;
DatePickerDialog.OnDateSetListener startDate;
DatePickerDialog.OnDateSetListener endDate;
final Calendar startCalendar=Calendar.getInstance();
final Calendar endCalendar=Calendar.getInstance();


        //method to update date button with date selected
    private void updateStartLabel(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        startButton.setText(sdf.format(startCalendar.getTime()));
    }
    private void updateEndLabel(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        endButton.setText(sdf.format(endCalendar.getTime()));
    }
    //inflate menu to allow sharing/notifications/etc
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_vacation_details, menu);
        return true;
    }
    //menu item actions
    public boolean onOptionsItemSelected(MenuItem item){
        if (item.getItemId() == R.id.share){
                List<Excursion> associatedExcursions = repository.getmAssociatedExcursions(id);
                Intent sendItent = new Intent();
                sendItent.setAction(Intent.ACTION_SEND);
                sendItent.putExtra(Intent.EXTRA_TEXT,"Vacation Title: "+
                        editVacationTitle.getText().toString() + "\nHotel Name: " + editHotel.getText().toString()
                        + "\nDates: " + startButton.getText().toString() + "-" + endButton.getText().toString()
                        + "\n" + associatedExcursions.toString().replace("[","").replace("]",""));
                sendItent.putExtra(Intent.EXTRA_TITLE, "Vacation Details");
                sendItent.setType("text/plain");
                Intent shareIntent = Intent.createChooser(sendItent, null);
                startActivity(shareIntent);
                return true;
        }
        else if(item.getItemId() == R.id.notifystart){
            String dateFromScreen = startButton.getText().toString();
            String myFormat = "MM/dd/yy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date myDate = null;
            try {
                myDate = sdf.parse(dateFromScreen);
            } catch (ParseException e) {e.printStackTrace();}
            Long trigger = myDate.getTime();
            Intent intent = new Intent(VacationDetails.this, MyReceiver.class);
            intent.putExtra("key", editVacationTitle.getText().toString() + " starts today!" );
            PendingIntent sender = PendingIntent.getBroadcast(VacationDetails.this, ++MainActivity.numAlert, intent, PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            return true;
        }
        else if(item.getItemId() == R.id.notifyend) {
            String dateFromScreen = endButton.getText().toString();
            String myFormat = "MM/dd/yy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date myDate = null;
            try {
                myDate = sdf.parse(dateFromScreen);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Long trigger = myDate.getTime();
            Intent intent = new Intent(VacationDetails.this, MyReceiver.class);
            intent.putExtra("key", editVacationTitle.getText().toString() + " ends today!");
            PendingIntent sender = PendingIntent.getBroadcast(VacationDetails.this, ++MainActivity.numAlert, intent, PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            return true;
        }
        else if(item.getItemId() == R.id.delete){
            List<Excursion> associatedExcursions = repository.getmAssociatedExcursions(id);
            if (associatedExcursions.size() < 1){
                for (Vacation vacation : repository.getmAllVacations()) {
                    if(vacation.getVacationID() == id) currentVacation = vacation;
                }
                repository.delete(currentVacation);
                Toast.makeText(VacationDetails.this, currentVacation.getVacationTitle() + " was deleted", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(VacationDetails.this, VacationList.class);
                startActivity(intent);
            } else{
                Toast.makeText(VacationDetails.this, "You cannot delete a vacation with attached excursions", Toast.LENGTH_LONG).show();
            }
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vacation_details);
        Button excursionButton=findViewById(R.id.addexcursion);


        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        String currentDate = sdf.format(new Date());
        // Set button dates for start/end vacation
        //if new vacation will populate current date
        //if existing vacation populates date from DB
        startButton=findViewById(R.id.startdate);
        endButton=findViewById(R.id.enddate);
        if(getIntent().getStringExtra("startVacation") == null){
            startButton.setText(currentDate);
        } else{
            startVacation=getIntent().getStringExtra("startVacation");
            startButton.setText(startVacation);
        }

        if(getIntent().getStringExtra("endVacation") == null) {
            endButton.setText(currentDate);
        } else{
            endVacation=getIntent().getStringExtra("endVacation");
            endButton.setText(endVacation);
        }
        //on click for start date to create calendar
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date date;
                String info = startButton.getText().toString();
                try {
                    startCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                new DatePickerDialog(VacationDetails.this,startDate,startCalendar.get(Calendar.YEAR),
                    startCalendar.get(Calendar.MONTH), startCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                startCalendar.set(Calendar.YEAR, year);
                startCalendar.set(Calendar.MONTH, month);
                startCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartLabel();
            }
        };
        //on click for end date to create calendar
        endButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date date;
                String info = endButton.getText().toString();
                try {
                    endCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                new DatePickerDialog(VacationDetails.this,endDate,endCalendar.get(Calendar.YEAR),
                        endCalendar.get(Calendar.MONTH), endCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                endCalendar.set(Calendar.YEAR, year);
                endCalendar.set(Calendar.MONTH, month);
                endCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndLabel();
            }
        };
        //Input fields for title, hotel, to be updated into SQL
        editVacationTitle=findViewById(R.id.vacationtitle);
        editHotel=findViewById(R.id.hotel);

        //use of vacation adapter
        id=getIntent().getIntExtra("id",-1);
        vacationTitle=getIntent().getStringExtra("vacationTitle");
        hotel=getIntent().getStringExtra("hotel");

        editVacationTitle.setText(vacationTitle);
        editHotel.setText(hotel);
        repository = new Repository(getApplication());
        Button button= findViewById(R.id.savevacation);

        //excursion adapter
        RecyclerView recyclerView=findViewById(R.id.excursionrecyclerview);
        final ExcursionAdapter excursionAdapter = new ExcursionAdapter(this);
        recyclerView.setAdapter(excursionAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        repository = new Repository(getApplication());

        //filter to only show excursions linked with vacation
        List<Excursion> filteredExcursions = new ArrayList<>();
        for(Excursion e : repository.getmAllExcursions()){
            if (e.getVacationID()==id) filteredExcursions.add(e);
        }
        excursionAdapter.setmExcursions(filteredExcursions);

        //onClick for saving insert/update
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (startButton.getText().toString().compareTo(endButton.getText().toString()) < 0 ){
                    if (id==-1){
                        vacation = new Vacation(0,editVacationTitle.getText().toString(),editHotel.getText().toString(),startButton.getText().toString(),endButton.getText().toString());
                        try {
                            repository.insert(vacation);
                            Intent intent = new Intent(VacationDetails.this, VacationList.class);
                            startActivity(intent);
                        } catch(Exception e){e.printStackTrace();}
                    }else {
                        vacation = new Vacation(id,editVacationTitle.getText().toString(),editHotel.getText().toString(),startButton.getText().toString(),endButton.getText().toString());
                        try{
                        repository.update(vacation);
                            Intent intent = new Intent(VacationDetails.this, VacationList.class);
                            startActivity(intent);
                        }catch (Exception e){e.printStackTrace();}
                    }
                }
            else{
                Toast.makeText(VacationDetails.this, "End of vacation must be after start of vacation",Toast.LENGTH_LONG).show();
                }}
        });
        //set intent to go to excursion detail page
        excursionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (id != -1){
                    Intent intent = new Intent(VacationDetails.this, ExcursionDetails.class);
                    intent.putExtra("vacationID",id);
                    //for validation that excursion occurs during vacation
                    intent.putExtra("startVacation",startButton.getText().toString());
                    intent.putExtra("endVacation",endButton.getText().toString());
                    startActivity(intent);}
                else{
                    Toast.makeText(VacationDetails.this, "You must save a vacation before trying to add an excursion.", Toast.LENGTH_SHORT).show();}
            }
        });
    }
    @Override
    protected void onResume(){
        super.onResume();
        //excursion resume
        RecyclerView recyclerView = findViewById(R.id.excursionrecyclerview);
        final ExcursionAdapter excursionAdapter = new ExcursionAdapter(this);
        recyclerView.setAdapter(excursionAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<Excursion> filteredExcursions = new ArrayList<>();
        for (Excursion e: repository.getmAllExcursions()){
            if(e.getVacationID()==id){filteredExcursions.add(e);}
        }
        excursionAdapter.setmExcursions(filteredExcursions);
    }

}