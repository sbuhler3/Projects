package com.example.vacation.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.vacation.R;
import com.example.vacation.database.Repository;
import com.example.vacation.entities.Excursion;
import com.example.vacation.entities.Vacation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ExcursionDetails extends AppCompatActivity {
    EditText editExcursionTitle;
    String excursionTitle;
    String startExcursion;
    String startVacation;
    String endVacation;
    int excursionID;
    int vacationID;
    Excursion excursion;
    Excursion currentExcursion;
    Repository repository;

    Button startButton;
    DatePickerDialog.OnDateSetListener startDate;
    final Calendar startCalendar= Calendar.getInstance();

    //method to update date button with date selected
    private void updateStartLabel(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        startButton.setText(sdf.format(startCalendar.getTime()));
    }
    //inflate menu to allow sharing/notifications/etc
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.excursion_details, menu);
        return true;
    }
    //menu item actions
    public boolean onOptionsItemSelected(MenuItem item){
         if(item.getItemId() == R.id.notifystart){
            String dateFromScreen = startButton.getText().toString();
            String myFormat = "MM/dd/yy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date myDate = null;
            try {
                myDate = sdf.parse(dateFromScreen);
            } catch (ParseException e) {e.printStackTrace();}
            Long trigger = myDate.getTime();
            Intent intent = new Intent(ExcursionDetails.this, MyReceiver.class);
            intent.putExtra("key", editExcursionTitle.getText().toString() + " starts today!" );
            PendingIntent sender = PendingIntent.getBroadcast(ExcursionDetails.this, ++MainActivity.numAlert, intent, PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            return true;
        }
         else if(item.getItemId() == R.id.delete){
             for (Excursion excursion : repository.getmAllExcursions()) {
                 if(excursion.getExcursionID() == excursionID) currentExcursion = excursion;
                 }
                 repository.delete(currentExcursion);
                 Toast.makeText(ExcursionDetails.this, currentExcursion.getExcursionTitle() + " was deleted", Toast.LENGTH_SHORT).show();
             Intent intent = new Intent(ExcursionDetails.this, VacationList.class);
             startActivity(intent);
             }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excursion_details);

        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        String currentDate = sdf.format(new Date());
        // Set button dates for start/end vacation
        //if new vacation will populate current date
        //if existing vacation populates date from DB
        startButton=findViewById(R.id.startexcursion);
        if(getIntent().getStringExtra("excursionDate") == null){
            startButton.setText(currentDate);
        } else{
            startExcursion=getIntent().getStringExtra("excursionDate");
            startButton.setText(startExcursion);
        }
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date date;
                String info = startButton.getText().toString();
                try {
                    startCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                new DatePickerDialog(ExcursionDetails.this,startDate,startCalendar.get(Calendar.YEAR),
                        startCalendar.get(Calendar.MONTH), startCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                startCalendar.set(Calendar.YEAR, year);
                startCalendar.set(Calendar.MONTH, month);
                startCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartLabel();
            }
        };
        //input fields for title to be updated into SQL
        editExcursionTitle=findViewById(R.id.excursiontitle);
        //use of excursion adapter
        excursionID=getIntent().getIntExtra("id",-1);
        vacationID=getIntent().getIntExtra("vacationID",-1);
        excursionTitle=getIntent().getStringExtra("excursionTitle");
        startVacation=getIntent().getStringExtra("startVacation");
        endVacation=getIntent().getStringExtra("endVacation");

        editExcursionTitle.setText(excursionTitle);
        repository = new Repository(getApplication());
        Button button = findViewById(R.id.saveexcursion);

        //onClick for saving insert/update
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((startButton.getText().toString().compareTo(startVacation) > 0 || startButton.getText().toString().compareTo(startVacation) == 0)
                        && (startButton.getText().toString().compareTo(endVacation) < 0 || startButton.getText().toString().compareTo(endVacation) == 0)){
                    if (excursionID==-1) {
                        excursion = new Excursion(0, editExcursionTitle.getText().toString(), startButton.getText().toString(), startVacation, endVacation, vacationID);
                        try {
                            repository.insert(excursion);
                            Intent intent = new Intent(ExcursionDetails.this, VacationList.class);
                            startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else{
                        excursion = new Excursion(excursionID,editExcursionTitle.getText().toString(),startButton.getText().toString(),startVacation,endVacation,vacationID);
                        try {
                            repository.update(excursion);
                            Intent intent = new Intent(ExcursionDetails.this, VacationList.class);
                            startActivity(intent);
                        } catch(Exception e){e.printStackTrace();}
                    }
            } else {
                    Toast.makeText(ExcursionDetails.this, "Excursion must be during vacation", Toast.LENGTH_LONG).show();
                }}
        });
    }
}