package com.example.vacation.UI;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vacation.R;
import com.example.vacation.entities.Vacation;

import java.util.List;

public class VacationAdapter extends RecyclerView.Adapter<VacationAdapter.VacationViewHolder> {
    class VacationViewHolder extends RecyclerView.ViewHolder {
        private final TextView vacationItemView;
        private VacationViewHolder(View itemview){
            super(itemview);
            vacationItemView=itemview.findViewById(R.id.list_item);
            itemview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position=getAdapterPosition();
                    final Vacation current=mVacations.get(position);
                    Intent intent = new Intent(context, VacationDetails.class);
                    intent.putExtra("id", current.getVacationID());
                    intent.putExtra("vacationTitle",current.getVacationTitle());
                    intent.putExtra("hotel",current.getHotel());
                    intent.putExtra("startVacation",current.getStartVacation());
                    intent.putExtra("endVacation", current.getEndVacation());
                    context.startActivity(intent);
                }
            });
        }
    }
    private List<Vacation> mVacations;
    private final Context context;
    private final LayoutInflater mInflater;
    public VacationAdapter(Context context){
        mInflater= LayoutInflater.from(context);
        this.context=context;
    }
    @NonNull
    @Override
    public VacationAdapter.VacationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View itemview=mInflater.inflate(R.layout.vacation_list_item,parent,false);
        return new VacationViewHolder((itemview));
    }

    @Override
    public void onBindViewHolder(@NonNull VacationAdapter.VacationViewHolder holder, int position){
    if(mVacations!=null){
        Vacation current=mVacations.get(position);
        String name=current.getVacationTitle();
        holder.vacationItemView.setText(name);
    }
    else{
        holder.vacationItemView.setText("No Vacation Name");
    }
    }

    @Override
    public int getItemCount(){
        return mVacations.size();
    }
    public void setVacations(List<Vacation> vacations){
        mVacations=vacations;
        notifyDataSetChanged();
    }

    public void setFilteredVacations(List<Vacation> filteredVacation){
        mVacations=filteredVacation;
        notifyDataSetChanged();
    }

}
