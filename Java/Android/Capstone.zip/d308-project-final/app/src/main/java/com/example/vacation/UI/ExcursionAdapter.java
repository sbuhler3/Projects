package com.example.vacation.UI;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vacation.R;
import com.example.vacation.entities.Excursion;
import com.example.vacation.entities.Vacation;

import java.util.List;

public class ExcursionAdapter extends RecyclerView.Adapter<ExcursionAdapter.ExcursionViewHolder> {
    class ExcursionViewHolder extends RecyclerView.ViewHolder {
        private final TextView excursionItemView1;
        private final TextView excursionItemView2;
        private ExcursionViewHolder(View itemview){
            super(itemview);
            excursionItemView1=itemview.findViewById(R.id.textViewExcursionName);
            excursionItemView2=itemview.findViewById(R.id.textViewExcursionDate);
            itemview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position=getAdapterPosition();
                    final Excursion current=mExcursions.get(position);
                    Intent intent = new Intent(context, ExcursionDetails.class);
                    intent.putExtra("id", current.getExcursionID());
                    intent.putExtra("excursionTitle", current.getExcursionTitle());
                    intent.putExtra("excursionDate", current.getExcursionDate());
                    intent.putExtra("vacationID", current.getVacationID());
                    intent.putExtra("startVacation", current.getStartVacation());
                    intent.putExtra("endVacation", current.getEndVacation());
                    context.startActivity(intent);
                }
            });
        }
    }
    private List<Excursion> mExcursions;
    private final Context context;
    private final LayoutInflater mInflater;
    public ExcursionAdapter(Context context){
        mInflater= LayoutInflater.from(context);
        this.context=context;
    }
    @NonNull
    @Override
    public ExcursionAdapter.ExcursionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View itemview=mInflater.inflate(R.layout.excursion_list_item,parent,false);
        return new ExcursionAdapter.ExcursionViewHolder((itemview));
    }

    @Override
    public void onBindViewHolder(@NonNull ExcursionAdapter.ExcursionViewHolder holder, int position){
        if(mExcursions!=null){
            Excursion current=mExcursions.get(position);
            String name=current.getExcursionTitle();
            String excursionDate = current.getExcursionDate();
            holder.excursionItemView1.setText(name);
            holder.excursionItemView2.setText(excursionDate);
        }
        else{
            holder.excursionItemView1.setText("No excursion name");
            holder.excursionItemView2.setText("No excursion date");
        }
    }

    @Override
    public int getItemCount(){
        return mExcursions.size();
    }
    public void setmExcursions(List<Excursion> excursions){
        mExcursions=excursions;
        notifyDataSetChanged();
    }
}
