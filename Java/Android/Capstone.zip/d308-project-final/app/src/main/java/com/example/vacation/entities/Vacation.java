package com.example.vacation.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;
import java.util.Set;

@Entity(tableName = "vacations")
public class Vacation {
    @PrimaryKey(autoGenerate = true)
    private int vacationID;
    private String vacationTitle;
    private String hotel;
    private String startVacation;
    private String endVacation;


    public Vacation(int vacationID, String vacationTitle, String hotel, String startVacation, String endVacation) {
        this.vacationID = vacationID;
        this.vacationTitle = vacationTitle;
        this.hotel = hotel;
        this.startVacation = startVacation;
        this.endVacation = endVacation;
    }

    public Vacation() {
    }

    public int getVacationID() {
        return vacationID;
    }

    public void setVacationID(int vacationID) {
        this.vacationID = vacationID;
    }

    public String getVacationTitle() {
        return vacationTitle;
    }

    public void setVacationTitle(String vacationTitle) {
        this.vacationTitle = vacationTitle;
    }

    public String getHotel() {
        return hotel;
    }

    public void setHotel(String hotel) {
        this.hotel = hotel;
    }

    public String getStartVacation() {
        return startVacation;
    }

    public void setStartVacation(String startVacation) {
        this.startVacation = startVacation;
    }

    public String getEndVacation() {
        return endVacation;
    }

    public void setEndVacation(String endVacation) {
        this.endVacation = endVacation;
    }
}
