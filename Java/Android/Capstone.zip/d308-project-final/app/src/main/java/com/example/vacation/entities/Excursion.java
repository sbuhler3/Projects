package com.example.vacation.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "excursions")
public class Excursion extends Vacation{
    @PrimaryKey(autoGenerate = true)
    private int excursionID;
    private String excursionTitle;
    private String excursionDate;
    private String startVacation;
    private String endVacation;
    private int vacationID;

    public Excursion(int excursionID, String excursionTitle, String excursionDate, String startVacation, String endVacation, int vacationID) {
        this.excursionID = excursionID;
        this.excursionTitle = excursionTitle;
        this.excursionDate = excursionDate;
        this.startVacation = startVacation;
        this.endVacation = endVacation;
        this.vacationID = vacationID;
    }

    public Excursion() {
    }

    public int getExcursionID() {
        return excursionID;
    }

    public void setExcursionID(int excursionID) {
        this.excursionID = excursionID;
    }

    public String getExcursionTitle() {
        return excursionTitle;
    }

    public void setExcursionTitle(String excursionTitle) {
        this.excursionTitle = excursionTitle;
    }

    public String getExcursionDate() {
        return excursionDate;
    }

    public void setExcursionDate(String excursionDate) {
        this.excursionDate = excursionDate;
    }

    public int getVacationID() {
        return vacationID;
    }

    public void setVacationID(int vacationID) {
        this.vacationID = vacationID;
    }

    public String getStartVacation() {
        return startVacation;
    }

    public void setStartVacation(String startVacation) {
        this.startVacation = startVacation;
    }

    public String getEndVacation() {
        return endVacation;
    }
    public String toString(){
        return "Excursion title: " + this.excursionTitle + "\nExcursion Date: " + this.excursionDate +"\n";
    }

    public void setEndVacation(String endVacation) {
        this.endVacation = endVacation;
    }
}

