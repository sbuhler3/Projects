package com.example.vacation.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.vacation.R;
import com.example.vacation.database.Repository;
import com.example.vacation.entities.Vacation;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class VacationList extends AppCompatActivity {
    private Repository repository;
    private SearchView searchView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vacation_list);
        RecyclerView recyclerView=findViewById(R.id.vactionrecyclerview);
        searchView=findViewById(R.id.search_bar);
        searchView.clearFocus();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterVacation(newText);
                return false;
            }
        });
        final VacationAdapter vacationAdapter = new VacationAdapter(this);
        recyclerView.setAdapter(vacationAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        repository=new Repository(getApplication());
        List<Vacation> allVacations=repository.getmAllVacations();
        FloatingActionButton fab = findViewById(R.id.floatingActionButton);
        vacationAdapter.setVacations(allVacations);


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VacationList.this, VacationDetails.class);
                startActivity(intent);
            }
        });
    }

    private void filterVacation(String text) {
        List<Vacation> filteredVacation = new ArrayList<>();
        for (Vacation vacation : repository.getmAllVacations()){
            if(vacation.getVacationTitle().toLowerCase().contains(text.toLowerCase())){
                filteredVacation.add(vacation);
            }
        }
        if (filteredVacation.isEmpty()){
            Toast.makeText(this,"No vacation was found in that search", Toast.LENGTH_LONG).show();
        }else{
            RecyclerView recyclerView = findViewById(R.id.vactionrecyclerview);
            final VacationAdapter vacationAdapter = new VacationAdapter(this);
            recyclerView.setAdapter(vacationAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            vacationAdapter.setFilteredVacations(filteredVacation);
        }
    }

    @Override
    protected void onResume(){
        super.onResume();
        List<Vacation> allVacations = repository.getmAllVacations();
        RecyclerView recyclerView = findViewById(R.id.vactionrecyclerview);
        final VacationAdapter vacationAdapter = new VacationAdapter(this);
        recyclerView.setAdapter(vacationAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        vacationAdapter.setVacations(allVacations);
    }
}