package com.example.vacation.database;

import android.app.Application;

import com.example.vacation.dao.ExcursionDAO;
import com.example.vacation.dao.VacationDAO;
import com.example.vacation.entities.Excursion;
import com.example.vacation.entities.Vacation;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {
    private VacationDAO mVacationDAO;
    private ExcursionDAO mExcursionDAO;
    private List<Vacation> mAllVacations;
    private List<Excursion> mAllExcursions;
    private List<Excursion> mAssociatedExcursions;

    private static int NUMBER_THREADS=4;
    static final ExecutorService dataBaseExecutor= Executors.newFixedThreadPool(NUMBER_THREADS);

    public Repository(Application application){
        DatabaseBuilder db= DatabaseBuilder.getDatabase(application);
        mVacationDAO=db.vacationDAO();
        mExcursionDAO=db.excursionDAO();
    }
    public List<Vacation>getmAllVacations(){
        dataBaseExecutor.execute(()->{
            mAllVacations=mVacationDAO.getAllVacations();
        });
        try{
        Thread.sleep(1000);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
        return mAllVacations;
    }
    public void insert(Vacation vacation) {
        dataBaseExecutor.execute(() -> {
            mVacationDAO.insert(vacation);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void update(Vacation vacation) {
        dataBaseExecutor.execute(() -> {
            mVacationDAO.update(vacation);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void delete(Vacation vacation) {
        dataBaseExecutor.execute(() -> {
            mVacationDAO.delete(vacation);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public List<Excursion>getmAllExcursions(){
        dataBaseExecutor.execute(()->{
            mAllExcursions=mExcursionDAO.getAllExcursions();
        });
        try{
            Thread.sleep(1000);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
        return mAllExcursions;
    }
    public List<Excursion>getmAssociatedExcursions(int id){
        dataBaseExecutor.execute(()->{
            mAssociatedExcursions=mExcursionDAO.getAllAssociatedExcursions(id);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
        return mAssociatedExcursions;
    }
    public void insert(Excursion excursion) {
        dataBaseExecutor.execute(() -> {
            mExcursionDAO.insert(excursion);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void update(Excursion excursion) {
        dataBaseExecutor.execute(() -> {
            mExcursionDAO.update(excursion);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void delete(Excursion excursion) {
        dataBaseExecutor.execute(() -> {
            mExcursionDAO.delete(excursion);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
