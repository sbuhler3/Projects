package com.example.vacation.entities;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
//unit test ensuring that for each attribute of excursion that get and set methods work
public class ExcursionUnitTest {
    Excursion excursion;

    @Before
    public void setUp(){excursion = new Excursion();}

    @Test
    public void excursionId(){
        int id = 90;
        excursion.setExcursionID(id);
        assertEquals(id, excursion.getExcursionID());
    }
    @Test
    public void excursionTitle(){
        String title = "Test Excursion";
        assertNull(excursion.getExcursionTitle());
        excursion.setExcursionTitle(title);
        assertEquals(title, excursion.getExcursionTitle());
    }
    @Test
    public void excursionDate(){
        String date = "01/01/23";
        assertNull(excursion.getExcursionDate());
        excursion.setExcursionDate(date);
        assertEquals(date, excursion.getExcursionDate());
    }
    @Test
    public void excursionVacationStart(){
        String date = "01/01/23";
        assertNull(excursion.getStartVacation());
        excursion.setStartVacation(date);
        assertEquals(date, excursion.getStartVacation());
    }
    @Test
    public void excursionVacationEnd(){
        String date = "01/02/23";
        assertNull(excursion.getEndVacation());
        excursion.setEndVacation(date);
        assertEquals(date, excursion.getEndVacation());
    }
    @Test
    public void excursionVacationId(){
        int id = 90;
        excursion.setVacationID(id);
        assertEquals(id, excursion.getVacationID());
    }
}
