package com.example.vacation.entities;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

//unit test ensuring that for each attribute of vacation that get and set methods work
public class VacationUnitTest {
    Vacation vacation;

    @Before
    public void setUp() {vacation = new Vacation();}

    @Test
    public void vacationId() {
        int id = 90;
        vacation.setVacationID(id);
        assertEquals(id,vacation.getVacationID());

    }
    @Test
    public void vacationTitle() {
       String title = "Test Hotel";
        assertNull(vacation.getVacationTitle());
        vacation.setVacationTitle(title);
        assertEquals(title, vacation.getVacationTitle());
    }
    @Test
    public void vacationStart(){
        String date = "01/01/2023";
        assertNull(vacation.getStartVacation());
        vacation.setStartVacation(date);
        assertEquals(date, vacation.getStartVacation());
    }
    @Test
    public void vacationEnd(){
        String date = "01/02/23";
        assertNull(vacation.getEndVacation());
        vacation.setEndVacation(date);
        assertEquals(date, vacation.getEndVacation());
    }
}
