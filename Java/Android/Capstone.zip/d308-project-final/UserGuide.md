Welcome to the vacation planning app! The purpose of this app is to centralize all the important
information for your trip into one convenient spot. 

This includes the name of your trip, the hotel you are staying at, the dates you will be gone, and
any excursions you will be embarking on. 

The signed APK is deployed to android Oreo.

The app will initially place you on the home screen. From here you click "Enter Site". This will take
you to the page that will list all of your vacations. You add a vacation by clicking the plus sign in 
the bottom right corner of the screen where it will ask you to fill out some details on a different screen.

On the vacation details page you must first hit save vacation before trying to add any excursions.
Once you have filled out all your details hit save and it will take you back to the vacation list page.

Now you should notice your vacation listed on the page. If you want to go in and edit anything about
your trip, or add excursions just click the name of the vacation to start editing. After you have made
your edits make sure to save by again clicking the save vacation button.

If you wish to add excursions to your vacation navigate to the vacation details page and then click
the add excursions button on the bottom right of the screen. This will take you to a excursion details page 
where you can fill out the necessary details. You may add as many excursions as you would like!

After filling out details for excursions hit save excursions and it will take you back to the vacation 
list page. If you select your vacation that has an excursion attached you will notice the excursion info
is now located on the vacation details page. If you would like to edit your excursion just click
the name or date of the excursion and it will take you to a page where you can edit. Make sure to save
after making your edits!

Other actions you can do while on the vacation details page are as follows: you may share the details
of your trip by clicking on the top right of the screen and selecting share. This will populate your
details into a text message. You can also click notify start or notify end which will send an alert to
your phone on the day your vacation starts and ends. Lastly you may delete your vacation from the
menu option, BUT you must have no excursions attached to the current vacation.

Other actions you can do while on the excursion details page are as follows: setting up notifications
for alerting you the day your excursion starts, and deleting excursions.
